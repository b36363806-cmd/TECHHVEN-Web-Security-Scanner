TECHHVEN WEB SECURITY SCANNER - TERMUX

INSTALL:
1. Install Termux from F-Droid or the official Termux GitHub release.
2. Open Termux and run:

pkg update && pkg upgrade -y
pkg install python unzip -y

3. Extract this ZIP into your Termux storage/downloads, then enter its folder.
   Example:
   termux-setup-storage
   cd ~/storage/downloads
   unzip TECHHVEN_WEB_SECURITY.zip
   cd TECHHVEN_WEB_SECURITY

4. Start:
   chmod +x start.sh
   ./start.sh

Alternative:
python main.py

FEATURES:
- Common admin/login URL discovery
- Basic HTTP response and security-header review
- Server/technology hints
- TLS certificate details
- Saves reports in reports/

IMPORTANT:
Use only on websites you own or have explicit permission to test.
A discovered admin URL is not an account or authorization.
This tool does not bypass logins, exploit vulnerabilities, or guess passwords.
Some servers block automated requests or return misleading status codes.
