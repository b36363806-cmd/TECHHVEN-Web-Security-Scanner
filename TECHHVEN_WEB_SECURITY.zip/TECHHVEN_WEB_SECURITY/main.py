#!/usr/bin/env python3
import ssl, socket, urllib.request, urllib.error, urllib.parse, re, sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime

GREEN = "\033[92m"
CYAN = "\033[96m"
YELLOW = "\033[93m"
RED = "\033[91m"
RESET = "\033[0m"

PATHS = [
    "admin", "admin/", "admin/login", "administrator", "administrator/login",
    "wp-admin", "wp-login.php", "login", "user/login", "dashboard",
    "controlpanel", "cpanel", "manage", "backend", "portal", "robots.txt",
    "sitemap.xml", ".well-known/security.txt"
]

def banner():
    print(CYAN + r"""
 _____ _____ ____ _   _ _   _ _   _ _____ _____ _   _
|_   _| ____/ ___| | | | | | | | | | ____|_   _| \ | |
  | | |  _| \___ \ |_| | |_| | |_| |  _|   | | |  \| |
  | | | |___ ___) |  _  |  _  |  _  | |___  | | | |\  |
  |_| |_____|____/|_| |_|_| |_|_| |_|_____| |_| |_| \_|
             WEB SECURITY SCANNER
""" + RESET)
    print(YELLOW + "Authorized testing only | No login bypass or password attacks\n" + RESET)

def get_target():
    raw = input("Target domain/URL: ").strip()
    if not raw:
        raise ValueError("Target cannot be empty.")
    if "://" not in raw:
        raw = "https://" + raw
    p = urllib.parse.urlsplit(raw)
    if p.scheme not in ("http", "https") or not p.hostname:
        raise ValueError("Enter a valid http:// or https:// URL.")
    if p.username or p.password:
        raise ValueError("Credentials in URLs are not accepted.")
    return f"{p.scheme}://{p.netloc}"

def request(url, timeout=8):
    req = urllib.request.Request(url, headers={"User-Agent": "TECHHVEN-WebSecurityScanner/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ssl.create_default_context()) as r:
            body = r.read(180000).decode("utf-8", "replace")
            return r.status, dict(r.headers), body, r.geturl()
    except urllib.error.HTTPError as e:
        try:
            body = e.read(50000).decode("utf-8", "replace")
        except Exception:
            body = ""
        return e.code, dict(e.headers), body, url
    except Exception as e:
        return None, {}, str(e), url

def show_headers(base):
    print(YELLOW + "\n[+] HTTP response and security headers" + RESET)
    status, headers, body, final = request(base)
    if status is None:
        print(RED + "Connection error: " + body + RESET)
        return
    print(f"URL: {final}\nHTTP status: {status}")
    for h in ("Server", "X-Powered-By", "Content-Type", "Location"):
        if h in headers:
            print(f"{h}: {headers[h]}")
    checks = {
        "Strict-Transport-Security": "HSTS",
        "Content-Security-Policy": "CSP",
        "X-Content-Type-Options": "X-Content-Type-Options",
        "X-Frame-Options": "X-Frame-Options",
        "Referrer-Policy": "Referrer-Policy",
        "Permissions-Policy": "Permissions-Policy"
    }
    print("\nSecurity header review:")
    for header, label in checks.items():
        if header in headers:
            print(GREEN + f"  PRESENT  {label}" + RESET)
        else:
            print(YELLOW + f"  MISSING  {label}" + RESET)
    title = re.search(r"<title[^>]*>(.*?)</title>", body, re.I | re.S)
    if title:
        print("Page title:", re.sub(r"\s+", " ", title.group(1)).strip()[:120])

def admin_discovery(base):
    print(YELLOW + "\n[+] Admin panel / common path discovery" + RESET)
    print("Checking a small list of common public paths...")
    def check(path):
        url = base.rstrip("/") + "/" + path.lstrip("/")
        status, headers, body, final = request(url, timeout=7)
        return path, status, final
    found = []
    with ThreadPoolExecutor(max_workers=5) as pool:
        futures = [pool.submit(check, p) for p in PATHS]
        for f in as_completed(futures):
            path, status, final = f.result()
            if status in (200, 301, 302, 401, 403):
                found.append((path, status, final))
                color = GREEN if status in (200, 301, 302) else YELLOW
                print(color + f"[{status}] /{path} -> {final}" + RESET)
    if not found:
        print("No listed paths responded with an interesting status.")
    print("\nNote: 401/403 means access is restricted, not that access was gained.")

def technology_check(base):
    print(YELLOW + "\n[+] Basic technology hints" + RESET)
    status, headers, body, final = request(base)
    if status is None:
        print(RED + body + RESET)
        return
    hints = []
    server = headers.get("Server")
    powered = headers.get("X-Powered-By")
    if server: hints.append("Server: " + server)
    if powered: hints.append("X-Powered-By: " + powered)
    low = body.lower()
    for marker, name in [
        ("wp-content", "WordPress"), ("/sites/default/", "Drupal"),
        ("joomla", "Joomla"), ("laravel", "Laravel hint"),
        ("react", "React hint"), ("next.js", "Next.js hint")
    ]:
        if marker in low: hints.append(name)
    print("\n".join(hints) if hints else "No clear technology hints detected.")

def ssl_check(base):
    print(YELLOW + "\n[+] TLS certificate check" + RESET)
    p = urllib.parse.urlsplit(base)
    if p.scheme != "https":
        print("Target uses HTTP; no TLS certificate to inspect.")
        return
    host = p.hostname
    port = p.port or 443
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((host, port), timeout=8) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as ss:
                cert = ss.getpeercert()
                print("TLS version:", ss.version())
                print("Certificate subject:", cert.get("subject"))
                print("Certificate expiry:", cert.get("notAfter"))
    except Exception as e:
        print(RED + "TLS check failed: " + str(e) + RESET)

def save_report(base, results_text):
    os.makedirs("reports", exist_ok=True)
    name = "reports/scan_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".txt"
    with open(name, "w", encoding="utf-8") as f:
        f.write("TECHHVEN WEB SECURITY SCANNER\n")
        f.write("Target: " + base + "\n")
        f.write("Date: " + datetime.now().isoformat() + "\n\n")
        f.write(results_text)
    print(GREEN + "Report saved: " + name + RESET)

def main():
    banner()
    try:
        base = get_target()
    except ValueError as e:
        print(RED + str(e) + RESET)
        return
    while True:
        print("\nTarget:", base)
        print("1. Admin panel & common path discovery")
        print("2. HTTP response & security headers")
        print("3. Server technology hints")
        print("4. TLS certificate check")
        print("5. Run all checks")
        print("6. Change target")
        print("0. Exit")
        choice = input("\nSelect: ").strip()
        if choice == "1": admin_discovery(base)
        elif choice == "2": show_headers(base)
        elif choice == "3": technology_check(base)
        elif choice == "4": ssl_check(base)
        elif choice == "5":
            show_headers(base); technology_check(base); ssl_check(base); admin_discovery(base)
        elif choice == "6":
            try: base = get_target()
            except ValueError as e: print(RED + str(e) + RESET)
        elif choice == "0":
            print("Bye.")
            break
        else:
            print("Invalid option.")

if __name__ == "__main__":
    main()
